package com.rft.rft_be;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RftBeApplicationTests {

	@Test
	void contextLoads() {
	}

}
