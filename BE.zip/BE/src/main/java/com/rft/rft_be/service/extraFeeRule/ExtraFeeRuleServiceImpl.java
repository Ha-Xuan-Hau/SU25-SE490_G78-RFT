package com.rft.rft_be.service.extraFeeRule;

public class ExtraFeeRuleServiceImpl {
}
